<?php

class Paymill_Paymillcc_LibraryVersion
{

    public function toOptionArray()
    {
        return array(
            array('value' => 'v2', 'label' => 'V2')
        );
    }

}